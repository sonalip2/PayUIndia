=== PayUIndia Plugin ===
Contributors: Tailored Solutions Pvt. Ltd.
Tags: payuindia, woocommerce plugin,
Donate link: http://tasolglobal.com
Requires at least: 4.0
Tested up to: 4.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

PayUIndia Onsite payment gives you all payment methods in your own site.It accepts all details of your card in your on site rather than payubiz payment gateway.

== Description ==
PayUIndia plugin is mainly used to collect your all details in your onsite not to payubiz payment gateway.you just need to add mechant key and salt to settings and you can integrate all methods.

== Installation ==
1. Download the plugin file.
2. Upload "PayUIndia" to the "/wp-content/plugins/" directory.
3. Activate the plugin through the "Plugins" menu in WordPress.


Note: This plugin requires WooCommerce in order to work.

== Frequently Asked Questions ==
Please use WordPress support forum to ask any query regarding any issue.

== Screenshots ==
1. screenshot-1.jpeg: This is PayUIndia Plugin Setting page.

== Changelog ==
= 1.0 30-12-2016 =
* Initial release.